const mainContent = document.getElementById("main-content");
const navButtons = document.querySelectorAll("[data-page]");
const header = document.getElementById("header");

let currentPage = "home";


function renderPage(page) {
  switch (page) {
    case "home":
      return `
        <section class="hero">
          <div class="hero-content">
            <h1>Строительство индивидуальных жилых домов</h1>
            <p>Создаем комфортные дома под ключ по индивидуальным проектам для вашего уюта и благополучия.</p>
            <button data-page="projects" class="btn-primary">Посмотреть проекты</button>
            <button data-page="contact" class="btn-secondary">Оставить заявку</button>
          </div>
        </section>
      `;
    case "services":
      return `
        <section class="section">
          <div class="container">
            <h2 class="section-title">Наши услуги</h2>
            <div class="services-grid">
              ${services.map(service => `
                <div class="service-card">
                  <div class="service-icon">${service.icon}</div>
                  <h3>${service.title}</h3>
                  <p>${service.description}</p>
                </div>
              `).join("")}
            </div>
          </div>
        </section>
      `;
    case "projects":
      return `
        <section class="section">
          <div class="container">
            <h2 class="section-title">Наши проекты</h2>
            <div class="projects-grid">
              ${projects.map(project => `
                <div class="project-card">
                  <img src="${project.image}" alt="${project.title}" style="width:100%;height:auto;">
                  <h3>${project.title}</h3>
                  <p>Площадь: ${project.area}</p>
                  <p>Комнаты: ${project.rooms}</p>
                  <p><strong>${project.price}</strong></p>
                  <button data-page="contact" class="btn-primary">Заказать проект</button>
                </div>
              `).join("")}
            </div>
          </div>
        </section>
      `;
    case "about":
      return `
        <section class="section">
          <div class="container">
            <h2 class="section-title">О компании</h2>
            <p>Мы специализируемся на строительстве индивидуальных жилых домов различных категорий сложности. Наш опыт позволяет нам создавать комфортные и функциональные дома, соответствующие самым высоким требованиям.</p>
            <p>Мы используем современные технологии и материалы, обеспечивая высокое качество исполнения и соблюдение сроков сдачи объектов.</p>
            <p>Наши клиенты получают полный цикл услуг — от проектирования до сдачи готового дома под ключ.</p>
          </div>
        </section>
      `;
    case "contact":
      return `
        <section class="section">
          <div class="container">
            <h2 class="section-title">Свяжитесь с нами</h2>
            <form class="space-y-4">
              <div>
                <label>Имя:</label>
                <input type="text" class="border w-full p-2 rounded" placeholder="Ваше имя">
              </div>
              <div>
                <label>Email:</label>
                <input type="email" class="border w-full p-2 rounded" placeholder="Ваш email">
              </div>
              <div>
                <label>Телефон:</label>
                <input type="tel" class="border w-full p-2 rounded" placeholder="+7 (XXX) XXX-XX-XX">
              </div>
              <div>
                <label>Сообщение:</label>
                <textarea rows="4" class="border w-full p-2 rounded"></textarea>
              </div>
              <button type="submit" class="btn-primary w-full">Отправить запрос</button>
            </form>
          </div>
        </section>
      `;
    default:
      return "<p>Страница не найдена</p>";
  }
}

function setActivePage(page) {
  currentPage = page;
  mainContent.innerHTML = renderPage(page);

  // Update active nav buttons
  navButtons.forEach(btn => {
    btn.classList.toggle("active", btn.dataset.page === page);
  });
}

document.addEventListener("click", e => {
  if (e.target.matches("[data-page]")) {
    const page = e.target.dataset.page;
    setActivePage(page);
  }
});



window.addEventListener("scroll", () => {
  header.classList.toggle("scrolled", window.scrollY > 20);
});

// Initial load
setActivePage(currentPage);